const express = require("express");
const routerHijab = express.Router()

let hijab = [{size:'s', warna:'hitam', namahijab:'Biru', harga:'18',create:new Date()},
                 {size:'m', warna:'hitam', namahijab:'pink', harga:'20',create:new Date()},
                 {size:'l', warna:'kuning', namahijab:'silver', harga:'25',create:new Date()},
                ]

const cari = (arrData,size) =>{
    ketemu = -1
    indeks = 0
    while(ketemu == -1 && indeks < arrData.length){
        if(arrData[indeks].size == size){
            ketemu = indeks
            return indeks
        }
        indeks++
    }
    return -1
}

routerHijab.route('/hijab')
    .get( (req,res)=>{
        res.json(hijab)
    })

    .post((req,res)=>{
        //Ambil data request dari front end
        const newItem = {
            size : req.body.size,
            warna : req.body.warna,
           namabatik : req.body.namahijab,
            harga : req.body.harga
        }
        batik.push(newItem)
        res.status(201).json(newItem)
    })

routerBatik.route('/hijab/:size')
    .put((req,res)=>{
       size = req.params.size
        indeks = cari(hijab,size)
        if(indeks != -1){
            batik[indeks].size = merk
            batik[indeks].warna = req.body.ukuran
            batik[indeks].namahijab = req.body.warna
            batik[indeks].harga = req.body.harga

            res.json(hijab[indeks])
        }
        else{
            res.send('Data hijab tidak ditemukan')
        }
        
    })

    .delete((req,res)=>{
        size = req.params.size
        indeks = cari(hijab,size)
        if(indeks != -1){
            batik.splice(indeks,1)
            res.send('Hijab dengan size ' + size + ' telah dihapus')
        }
        else
        {
            res.send('Data hijab tidak ditemukan')
        }
        
    })

    .get((req,res)=>{
        size = req.params.size
        indeks = cari(hijab,size)
        if(indeks != -1){
            const dataHijab = {size:hijab[indeks].size,
                                   warna:hijab[indeks].warna,
                                   namahijab:hijab[indeks].namahijab,
                                   harga:hijab[indeks].harga
                                  }
            res.json(dataHijab)
        }
        else{
            res.send('Hijab dengan size : ' +size + ' tidak ditemukan')
        }
        
    })

routerHijab.get('/hijab/:warna/:terlaris', (req,res)=>{
    const warna = req.params.warna
    const terlaris = req.params.terlaris
    res.send('Hijab warna : ' + warna + ' terlaris : ' + terlaris)
})

module.exports = routerHijab