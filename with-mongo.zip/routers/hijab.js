const express = require("express");
const routerHijab = express.Router()
const controllerHijab = require('../controllers/hijab')

routerHijab.route('/hijab')
    .get(controllerHijab.getSepatu)
    .post(controllerHijab.insert)

routerHijab.route('/hijab/:merk')
    .put(controllerHijab.update)
    .delete(controllerHijab.delete)
    .get(controllerHijab.getHijabByMerk)

routerHijab.route('/hijab/produk/:merk')
    .get(controllerHijab.getProdukByMerk)
    .put(controllerHijab.insertProduk)

module.exports = routerHijab