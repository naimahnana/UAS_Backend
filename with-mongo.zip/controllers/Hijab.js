const Hijab = require('../models/hjbEmbedded')


module.exports = {
    insert : async (req,res)=>{
        //Ambil data request dari front end
        const data = new Hijab({
            merk : req.body.merk,
            ukuran : req.body.ukuran,
            warna : req.body.warna,
            harga : req.body.harga,
        })
        try {
            const dataToSave = await data.save()
            res.status(200).json(dataToSave)
        } catch (error) {
            res.status(400).json({message:error.message})
        }
    },

    insertProduk: async (req,res)=>{
        const merk = req.params.merk

        try{
            await Hijab.updateOne(
                {"merk":merk},
                {
                    $push:{
                        "produk":{
                            "kode": req.body.kode,
                            "jenisproduk": req.body.jenisproduk,
                            "kualitas":req.body.kualitas,
                            'ukuranproduk':req.body.ukuranproduk,
                            "harga": req.body.harga,
                        }
                    }
                })
            res.send('Produk telah di simpan')
            } catch (error){
                res.status(409).json({message: error.message})
            }
    },
    
    getSepatu : async (req,res)=>{
        try {
            const result = await Sepatu.find()
            res.status(200).json(result)
        } catch (error) {
            res.status(404).json({message : error.message})
        }
    },
    getSepatuByMerk : async (req,res)=>{
         const merk = req.params.merk
         try {
             const result = await Sepatu.find().where('merk').equals(merk)
             res.json(result)
         } catch (error) {
             res.status(500).json({message: error.message})
         }
    },

    getHijabByMerk : async (req,res) => {
        const merk = req.params.merk;
        try{
            const result = await Hijab.findOne({"merk": merk}, {"_id":0,"produk": 1})
            /* let res2 =[];
            for (let i = 0; i < result.lenght i++){
                res2.push(result[i])
            }*/
            res.json(result)
        } catch (error){
            res.status(500).json({ message : error.message})
        }
    },
    update : async (req,res)=>{
        const filter = {merk : req.params.merk}
        const updatedData = {
            ukuran : req.body.ukuran,
            warna : req.body.warna,
            harga : req.body.harga
        }
        try {
            let result = await Hijab.updateOne(filter,updatedData)
            res.send('Data telah terupdate')
        } catch (error) {
            res.status(409).json({message : error.message})
        }
        
    },

    delete : async (req,res)=>{
        const filter = {merk : req.params.merk}
        try {
            await Hijab.deleteOne(filter);
            res.send('Data telah terhapus')
        } catch (error) {
            res.status(409).json({message : error.message})
        }
        
    }
}