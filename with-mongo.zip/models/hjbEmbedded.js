const mongoose = require('mongoose')

const sptEmbeddedSchema = new mongoose.Schema({
    merk:{
        required: true,
        type: String
    },
    ukuran:{
        required: true,
        type: String
    },
    warna:{
        required: true,
        type: String
    },
    harga:{
        required: true,
        type: String
    },
    produk: [{
        kode : String,
        jenisproduk : String,
        kualitas : String,
        ukuranproduk : String,
        harga : String
    }]
})

module.exports = mongoose.model('Hijab', sptEmbeddedSchema,'hijab')